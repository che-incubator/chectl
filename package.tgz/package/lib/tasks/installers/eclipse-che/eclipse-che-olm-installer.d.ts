/**
 * Copyright (c) 2019-2021 Red Hat, Inc.
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *   Red Hat, Inc. - initial API and implementation
 */
import Listr = require('listr');
import { Installer } from '../installer';
export declare class EclipseCheOlmInstaller implements Installer {
    getDeployTasks(): Listr.ListrTask<any>;
    getPreUpdateTasks(): Listr.ListrTask<any>;
    getUpdateTasks(): Listr.ListrTask<any>;
    getDeleteTasks(): Listr.ListrTask<any>;
    addCommonInstallTasks(tasks: Listr): Promise<void>;
}
